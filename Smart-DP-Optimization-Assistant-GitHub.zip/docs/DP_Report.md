# Dynamic Programming Optimization Report

## Algorithm Recurrence Relations

### 1. Longest Common Subsequence (LCS)
$$LCS[i][j] = \begin{cases} 0 & \text{if } i=0 \text{ or } j=0 \\ 1 + LCS[i-1][j-1] & \text{if } X[i-1] = Y[j-1] \\ \max(LCS[i-1][j], LCS[i][j-1]) & \text{otherwise} \end{cases}$$

### 2. 0/1 Knapsack Problem
$$K[i][w] = \max(val[i-1] + K[i-1][w-wt[i-1]], K[i-1][w])$$

### 3. Matrix Chain Multiplication (MCM)
$$m[i][j] = \min_{i \le k < j} (m[i][k] + m[k+1][j] + p_{i-1}p_kp_j)$$
