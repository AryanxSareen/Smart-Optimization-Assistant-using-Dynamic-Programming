# Smart DP Optimization Assistant

A comprehensive Dynamic Programming (DP) web application designed for analyzing and visualizing core algorithms:
1. **Longest Common Subsequence (LCS)** - Sequence Analysis
2. **0/1 Knapsack Problem** - Resource Allocation
3. **Matrix Chain Multiplication (MCM)** - Computation Optimization

## Features
- Interactive 2D Dynamic Programming table visualization.
- Real-time performance benchmarking suite with Chart.js.
- Automated ZIP packaging for GitHub lab submissions.

## Running Locally
Simply open `index.html` in any web browser. No npm install or server dependencies required!
